# libfilesystem
cross-platform library and c++ api for filesystem-related functionality

[Click Here for Documentation](https://github.com/time-killer-games/libfilesystem/blob/master/libfilesystem.pdf)
